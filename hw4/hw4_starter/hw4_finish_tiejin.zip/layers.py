from builtins import range
import numpy as np
import math
import scipy.signal


def fc_forward(x, w, b):
    """
    Computes the forward pass for a fully-connected layer.
    The input x has shape (N, d_in) and contains a minibatch of N
    examples, where each example x[i] has d_in element.
    Inputs:
    - x: A numpy array containing input data, of shape (N, d_in)
    - w: A numpy array of weights, of shape (d_in, d_out)
    - b: A numpy array of biases, of shape (d_out,)
    Returns a tuple of:
    - out: output, of shape (N, d_out)
    - cache: (x, w, b)
    """

    out = np.dot(x,w) +b
    cache = (x, w, b)
    return out, cache


def fc_backward(dout, cache):
    """
    Computes the backward pass for a fully_connected layer.
    Inputs:
    - dout: Upstream derivative, of shape (N, d_out)
    - cache: Tuple of:
      - x: Input data, of shape (N, d_in)
      - w: Weights, of shape (d_in, d_out)
      - b: Biases, of shape (d_out,)
    Returns a tuple of:
    - dx: Gradient with respect to x, of shape (N, d_in)
    - dw: Gradient with respect to w, of shape (d_in, d_out)
    - db: Gradient with respect to b, of shape (d_out,)
    """
    x, w, b = cache
    dx = np.dot(dout,w.T)
    db = np.sum(dout,axis=0)
    dw = np.dot(x.T,dout)
    return dx, dw, db


def relu_forward(x):
    """
    Computes the forward pass for a layer of rectified linear units (ReLUs).
    Input:
    - x: Inputs, of any shape
    Returns a tuple of:
    - out: Output, of the same shape as x
    - cache: x
    """
    out = np.maximum(x,0)
    cache = x
    return out, cache


def relu_backward(dout, cache):
    """
    Computes the backward pass for a layer of rectified linear units (ReLUs).
    Input:
    - dout: Upstream derivatives, of any shape
    - cache: Input x, of same shape as dout
    Returns:
    - dx: Gradient with respect to x
    """
    dx, x = None, cache
    dx = dout.copy()
    dx[x < 0] = 0
    return dx


def conv_forward(x, w):
    """
    The input consists of N data points, each with C channels, height H and
    width W. We filter each input with F different filters, where each filter
    spans all C channels and has height H' and width W'.
    Input:
    - x: Input data of shape (N, C, H, W)
    - w: Filter weights of shape (F, C, H', W')
    Returns a tuple of:
    - out: Output data, of shape (N, F, HH, WW) where H' and W' are given by
      HH = H - H' + 1
      WW = W - W' + 1
    - cache: (x, w)
    """
    HH = x.shape[2] - w.shape[2] +1
    WW = x.shape[3] - w.shape[3] +1
    ph = w.shape[2]
    pw = w.shape[3]
    x_temp = np.transpose(x,(0,2,3,1))
    w_temp = np.transpose(w,(2,3,1,0))
    # out = np.zeros(shape=(x.shape[0],w.shape[0],HH,WW))
    # for n in range(w.shape[0]):
    #     temp_w = w[n]
    #     for i in range(HH):
    #         for j in range(WW):
    #             temp_res = np.sum(x[:,:,i:i+ph,j:j+pw]*temp_w,axis=(1,2,3))
    #             out[:,n,i,j] = temp_res
    windows = []
    for i in range(HH):
        for j in range(WW):
            window = x_temp[:,i:i+ph,j:j+pw:]
            windows.append(window)
    stacked_x = np.stack(windows).reshape(-1,ph*pw*x.shape[1])
    w_flat = w_temp.reshape(ph*pw*w.shape[1],w.shape[0])
    out = np.dot(stacked_x,w_flat).reshape(HH,WW,x.shape[0],w.shape[0])
    out = np.transpose(out,(2,3,0,1))
    cache = (x, w)
    return out, cache


def conv_backward(dout, cache):
    """
    Inputs:
    - dout: Upstream derivatives.
    - cache: A tuple of (x, w) as in conv_forward
    Returns a tuple of:
    - dx: Gradient with respect to x
    - dw: Gradient with respect to w
    """
    x, w = cache
    F, C, H1, W1 = w.shape

    # for i in range(HH):
    #     for j in range(WW):
    #         for n in range(x.shape[0]):
    #             for f in range(w.shape[0]):
    #                 dx[n,:,i:i+w.shape[2],j:j+w.shape[3]] += w[f]*dout[n,f,i,j]
    #                 dw[f] += x[n,:,i:i+w.shape[2],j:j+w.shape[3]]*dout[n,f,i,j]
    padding_dout= np.lib.pad(dout, ((0, 0), (0, 0), (H1 - 1, H1 - 1), (W1 - 1, W1 - 1)), 'constant',
                                  constant_values=0)
    flip_w = np.flip(w, (2, 3))
    swap_flip_w = np.swapaxes(flip_w, 0, 1)
    dx,_ = conv_forward(padding_dout,swap_flip_w)
    swap_x = np.swapaxes(x, 0, 1)
    swap_dout = np.swapaxes(dout,0,1)
    dw,_ = conv_forward(swap_x,swap_dout)
    dw = np.swapaxes(dw,0,1)
    ###########################################################################
    # TODO: Implement the convolutional backward pass as defined in Q1(c)     #
    #                                                                         #
    # Note: You are free to use scipy.signal.convolve2d, but we encourage you #
    # to implement the convolution operation by yourself using just numpy     #
    # operations.                                                             #
    ###########################################################################
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return dx, dw


def max_pool_forward(x, pool_param):
    """
    A naive implementation of the forward pass for a max-pooling layer.
    Inputs:
    - x: Input data, of shape (N, C, H, W)
    - pool_param: dictionary with the following keys:
      - 'pool_height': The height of each pooling region
      - 'pool_width': The width of each pooling region
      - 'stride': The distance between adjacent pooling regions
    No padding is necessary here and we can assume that the dimension of
    input and stride will not cause problem here. Output size is given by
    Returns a tuple of:
    - out: Output data, of shape (N, C, H', W') where H' and W' are given by
      H' = 1 + (H - pool_height) / stride
      W' = 1 + (W - pool_width) / stride
    - cache: (x, pool_param)
    """
    ph = pool_param['pool_height']
    pw = pool_param['pool_width']
    stride = pool_param['stride']
    Hout = 1 + int((x.shape[2]-ph)/stride)
    Wout = 1+ int((x.shape[3]-pw)/stride)
    out = np.zeros((x.shape[0],x.shape[1],Hout,Wout))
    mask = np.zeros((x.shape[0],x.shape[1],Hout,Wout,ph,pw))
    for i in range(Hout):
        for j in range(Wout):
            windows = x[:,:,i*stride:i*stride+ph,j*stride:j*stride+pw]
            out[:,:,i,j] = np.max(windows,axis=(2,3))
            temp_out = out[:,:,i,j].reshape(out.shape[0],out.shape[1],1,1)
            temp_out = temp_out.repeat(ph,axis=2).repeat(pw,axis=3)
            mask[:,:,i,j,:,:] = np.equal(windows,temp_out).astype(int)
    # windows = np.lib.stride_tricks.as_strided(x,
    #                      shape=(x.shape[0], x.shape[1], Hout, Wout, ph,pw),
    #                      strides=(x.strides[0], x.strides[1],
    #                               stride * x.strides[2],
    #                               stride * x.strides[3],
    #                               x.strides[2], x.strides[3])
    #                      )
    # out = np.max(windows, axis=(4, 5))
    pool_param['mask'] = mask
    cache = (x, pool_param)
    return out, cache


def max_pool_backward(dout, cache):
    """
    A naive implementation of the backward pass for a max-pooling layer.
    Inputs:
    - dout: Upstream derivatives
    - cache: A tuple of (x, pool_param) as in the forward pass.
    Returns:
    - dx: Gradient with respect to x
    """
    dx = None
    x, pool_param = cache
    dx = np.zeros_like(x)
    ph = pool_param['pool_height']
    pw = pool_param['pool_width']
    stride = pool_param['stride']
    Hout = 1 + int((x.shape[2]-ph)/stride)
    Wout = 1+ int((x.shape[3]-pw)/stride)
    mask = pool_param['mask']
    # for i in range(Hout):
    #     for j in range(Wout):
    #         windows = x[:, :, i * stride:i * stride + ph, j * stride:j * stride + pw]
    #         temp = np.max(windows,axis=3)
    #         temp = np.max(temp,axis=2)
    #         temp = temp.reshape((x.shape[0]*x.shape[1],1)).dot(np.ones((1,ph*pw)))
    #         temp =temp.reshape((x.shape[0],x.shape[1],ph,pw))
    #         mask = (windows == temp)
    #         dtemp = dout[:,:,i,j].reshape((x.shape[0]*x.shape[1],1)).dot(np.ones((1,ph*pw)))
    #         dtemp = dtemp.reshape((x.shape[0],x.shape[1],ph,pw))
    #         dx[:,:,i*stride:i*stride+ph,j*stride:j*stride+pw] += dtemp * mask
    for i in range(Hout):
        for j in range(Wout):
            temp_dout = dout[:,:,i,j].reshape(x.shape[0],x.shape[1],1,1)
            temp_dout = temp_dout.repeat(ph,axis=2).repeat(pw,axis=3)
            dx[:, :, i * stride:i * stride + ph, j * stride:j * stride + pw] += \
                temp_dout * mask[:,:,i,j,:,:]
    # for i in range(Hout):
    #     for j in range(Wout):
    #         windows = x[:, :, i * stride:i * stride + ph, j * stride:j * stride + pw]
    #         temp_dout = dout[:, :, i, j].reshape(x.shape[0], x.shape[1], 1, 1)
    #         temp_dout = temp_dout.repeat(ph,axis=2).repeat(pw,axis=3)
    #         out = np.max(windows,axis=(2,3))
    #         out = out.reshape(out.shape[0], out.shape[1], 1, 1)
    #         out = out.repeat(ph, axis=2).repeat(pw, axis=3)
    #         mask = np.equal(windows,out).astype(int)
    #         dx[:,:,i*stride:i*stride+ph,j*stride:j*stride+pw] += temp_dout * mask
    return dx


def softmax_loss(x, y):
    """
    Computes the loss and gradient for softmax classification.
    Inputs:
    - x: Input data, of shape (N, C) where x[i, j] is the score for the j-th
      class for the i-th input.
    - y: Vector of labels, of shape (N,) where y[i] is the label for x[i] and
      0 <= y[i] < C
    Returns a tuple of:
    - loss: Scalar giving the cross-entropy loss averaged over N samples.
    - dx: Gradient of the loss with respect to x
    """
    shift_score = x - np.max(x, axis=1, keepdims=True)
    shift_score_exp = np.exp(shift_score)
    shift_score_exp_sum = np.sum(shift_score_exp, axis=1, keepdims=True)
    score_norm = shift_score_exp / shift_score_exp_sum
    N = x.shape[0]
    loss = np.sum(-np.log(score_norm[range(score_norm.shape[0]), y])) / N
    dx = score_norm
    dx[range(N),y] -=1
    dx /= N
    return loss, dx
