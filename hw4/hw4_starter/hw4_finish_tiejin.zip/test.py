import numpy as np

a = np.array([[[1,-2],[2,-1]],[[1,2],[2,1]]])
b = np.array([[[-1,2],[-2,1]],[[1,2],[2,1]]])
c = np.array([a,b])
print(c.shape)
d = np.array([[2,2],[2,2]])
e = np.array([[-1,-1],[-1,-1]])
f = np.array([d,e])
g = np.array([1,1,1])
b = np.array([[1,2,3],[4,5,6],[7,8,9]])
b =np.lib.pad(b, ( (3- 1, 3 - 1), (0,0)), 'constant',
                                  constant_values=0)
print(b)